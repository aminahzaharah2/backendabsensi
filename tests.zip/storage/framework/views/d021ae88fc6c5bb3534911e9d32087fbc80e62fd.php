<!doctype html>
<html>

<body>
    <h1>User Email Verification</h1>
    <p>Hello <?php echo e($user->first_name); ?></p>
    <p>Please click the below button to verify your email address</p>
    <a href="<?php echo e(URL::temporarySignedRoute('verification.verify', now()->addMinutes(30), ['id' => $user->id])); ?>"
        class="button button-primary">Click To Verify</a>
</body>

</html><?php /**PATH E:\Magang Zahra\BackendAbsensi\resources\views/mail/name.blade.php ENDPATH**/ ?>